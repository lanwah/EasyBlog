const BaseUrl = baseUrl;
class Index {
    blogs = [];
    allBlogs = [];
    catalogs = [];
    webInfo;
    constructor() {
        document.addEventListener('DOMContentLoaded', () => this.init());
    }
    init() {
    }
}
new Index();
